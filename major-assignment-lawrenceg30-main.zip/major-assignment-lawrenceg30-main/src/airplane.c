// The airplane module contains the airplane data type and management functions

#include <stdlib.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>


#include "airplane.h"

/************************************************************************
 * plane_init initializes an airplane structure in the initial PLANE_UNREG
 * state, with given send and receive FILE objects.
 */
void airplane_init(airplane *plane, FILE *fp_send, FILE *fp_recv) {
    plane->state = PLANE_UNREG;
    plane->fp_send = fp_send;
    plane->fp_recv = fp_recv;
    plane->id[0] = '\0';
}


airplane *create_plane(int comm_fd){
    //memory for new plane
    
    airplane* newplane= malloc(sizeof(airplane));
    if (newplane == NULL) {
        perror("malloc of newplane");
        exit(1);
    }
   
    //duplicate comm_fd to have sender revever
    int dup_fd = dup(comm_fd);
    if(dup_fd < 0){
        perror("dup");
        free(newplane);
        return NULL;
    }

    //wrap file into file streams
    //sender
    FILE* sender = fdopen(comm_fd, "w");
    if(sender == NULL){
        perror("fdopen sender");
        close(dup_fd);
        close(comm_fd);
        free(newplane);
        return NULL;
    }
    

    FILE* receiver = fdopen(dup_fd, "r");
    if(receiver == NULL) {
        perror("fdopen receiver");
        fclose(sender);
        close(dup_fd);
        free(newplane);
        exit(1);
    }
   

    setvbuf(sender, NULL, _IOLBF,0);
    setvbuf(receiver, NULL, _IOLBF,0);
    airplane_init(newplane, sender, receiver);
    //init_client(newclient,sender,receiver);

    //return client
    return newplane;
}

/************************************************************************
 * plane_destroy frees up any resources associated with an airplane, like
 * file handles, so that it can be free'ed.
 */
void airplane_destroy(airplane *plane) {
    fclose(plane->fp_send);
    fclose(plane->fp_recv);
}

// Prototypes for utility functions

#ifndef _UTIL_H
#define _UTIL_H

char *trim(char *line);

#endif  // _UTIL_H

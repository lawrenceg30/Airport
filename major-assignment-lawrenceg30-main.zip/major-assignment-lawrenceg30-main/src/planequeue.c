
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

#include "airs_protocol.h"
#include "planequeue.h"
#include "planelist.h"
#include "alist.h"


/*
 This is a "queue of strings" implementation. 
*/

static alist plane_que;

static pthread_rwlock_t quelock; 

/******************************************************************
 * Initialize a queue (it starts empty)
 */
void queue_init(void) {
    alist_init(&plane_que, free);
    pthread_rwlock_init(&quelock, NULL);
}

/*
 * Add a new flight id to the queue
 */
void queue_enqueue(airplane *plane, char *name) {
   char *plane = (char *) malloc(sizeof(name));
   strcpy(plane, name);

    pthread_rwlock_wrlock(&quelock);
    alist_add(&plane_que, plane);
    pthread_rwlock_unlock(&quelock);

    if(alist_size(&plane_que) == 1) {
        plane->state = 4;
        send_ok(plane);
        fprintf(plane->fp_send, "TAKEOFF \n");
        return;
    }
    send_ok(plane); 
}


/******************************************************************
 * Remove the name at the front of the queue. Calls with an empty
 * queue will be ignored.
 */
void queue_dequeue(char *q) {
    pthread_rwlock_wrlock(&quelock);
    for(int i=0; i<alist_size(&plane_que);i++) {
       if ( strcmp(alist_get(&plane_que, i),q) == 0) {
           alist_remove(&plane_que, i);
            pthread_rwlock_unlock(&quelock);
            return;
       }
   }
    pthread_rwlock_unlock(&quelock);
}


void queue_pos(airplane *q, char *name) {
     pthread_rwlock_wrlock(&quelock);
    for(int i=0; i<alist_size(&plane_que); i++){
        if(strcmp(name, alist_get(&plane_que, i)) == 0) {
            fprintf(q->fp_send, "OK: %d\n", i+1);
              pthread_rwlock_unlock(&quelock);
            return; 
        }
    }
}
//prints the planes within the queue
void queue_print(airplane *q, char *name) {
    pthread_rwlock_wrlock(&quelock);
    for(int i=0; i<alist_size(&plane_que); i++){
         if(strcmp(name, alist_get(&plane_que, i)) == 0) {
             fprintf(q->fp_send, "%s, ", (char *) alist_get(&plane_que, i));
             fflush(q->fp_send);
         }else {
            pthread_rwlock_unlock(&quelock);
             return i;
         }

    }
     pthread_rwlock_unlock(&quelock);
}

//gets id that is next in line
void *queue_next(airplane *q, int position) {
    return(alist_get(&plane_que, position));
}

//returns size of plane que list
int queue_size() {
    return (alist_size(&plane_que));
}

//get postion of the plane id
int queue_position(char *name) {
    pthread_rwlock_wrlock(&quelock);
    for(int i=0; i<alist_size(&plane_que); i++) {
        if(strcmp(name, alist_get(&plane_que, i)) == 0) {
             pthread_rwlock_unlock(&quelock);
             return i;

        }
    }
    pthread_rwlock_unlock(&quelock);
    return -1;
}
#include <pthread.h>


#ifndef _QUEUE_H
#define _QUEUE_H

void queue_print(airplane *q, char *name);
void queue_enqueue(airplane *plane, char *name);
void queue_dequeue(char *q);
void queue_pos(airplane *q, char *name);
void *queue_next(airplane *q, int position);
int queue_position(char *name);

#endif

# Grading Report

Assignment Grade: 95/100

## Submission and Compilation

Good clean compilation.

This section: 20/20

## Correctness Tests

### Checking for major errors (seg faults, invalid memory access, leaks)

This section: 25/25

### Basic network communication test

No response after a simple connect and command

This section: 35/35

## Code Quality (Style, Robustness, and Design)

Moderate style issues (-5). Please format your code before submitting!
This section: 15/20


# Grading Report

Assignment Grade: 45/100

## Submission and Compilation

Submission not tagged properly (no tag or bad tag). [5 points]

Compilation failed. Could not produce executables, so no way
to run tests.  Maximum grade in this situation is 50.

Compilation errors (truncated to 20 lines):

```
src/gndcontrol.c: In function ‘main’:
src/gndcontrol.c:145:32: warning: implicit declaration of function ‘new_airplane’ [-Wimplicit-function-declaration]
145 |         airplane *new_client = new_airplane(comm_fd);
|                                ^~~~~~~~~~~~
src/gndcontrol.c:145:32: warning: initialization of ‘airplane *’ {aka ‘struct airplane *’} from ‘int’ makes pointer from integer without a cast [-Wint-conversion]
In file included from src/planequeue.c:9:
src/airs_protocol.h:6:14: error: unknown type name ‘airplane’
6 | void send_ok(airplane *plane);
|              ^~~~~~~~
src/airs_protocol.h:7:15: error: unknown type name ‘airplane’
7 | void send_err(airplane *plane, char *desc);
|               ^~~~~~~~
src/airs_protocol.h:8:20: error: unknown type name ‘airplane’
8 | void send_err_sarg(airplane *plane, char *fmtstring, char *sarg);
|                    ^~~~~~~~
src/airs_protocol.h:10:16: error: unknown type name ‘airplane’
10 | void docommand(airplane *plane, char *command);
|                ^~~~~~~~
In file included from src/planequeue.c:10:
src/planequeue.h:7:18: error: unknown type name ‘airplane’
```

Code examined to estimate level of completion.

This section: 45/100

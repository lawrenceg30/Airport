# Grading Report

Assignment Grade: 93/100

## Submission and Compilation

Good clean compilation.

This section: 20/20

## Correctness Tests

* Memory leak -- didn't free up getline-allocated memory [2 pts]

This section: 58/60

## Code Quality (Style, Robustness, and Design)

Minor-to-moderate formatting issues. Please format your code before submitting!

This section: 15/20

